﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AssignDemo;


namespace WebFormDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Class1 obj;
        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            obj = new Class1();
            obj.No1 = Convert.ToInt32(textBox1.Text);
            obj.No2 = Convert.ToInt32(textBox2.Text);
            label3.Text = Convert.ToString(obj.Sub());
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            obj = new Class1();
            obj.No1 = Convert.ToInt32(textBox1.Text);
            obj.No2 = Convert.ToInt32(textBox2.Text);
            label3.Text = Convert.ToString(obj.Mul());
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            obj = new Class1();
            obj.No1 = Convert.ToInt32(textBox1.Text);
            obj.No2 = Convert.ToInt32(textBox2.Text);
            label3.Text = Convert.ToString(obj.Div());
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            obj = new Class1();
            obj.No1 = Convert.ToInt32(textBox1.Text);
            obj.No2 = Convert.ToInt32(textBox2.Text);
            label3.Text = Convert.ToString(obj.Add());
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}
